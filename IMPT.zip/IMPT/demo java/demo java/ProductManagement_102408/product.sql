

create table products(
product_code number primary key,
product_name varchar2(20),
product_category varchar2(20),
product_descrption varchar2(30),
product_price number
);
insert into PRODUCTS values(1001,'iPhone','Electronics','SmartPhone',35000);
insert into PRODUCTS values(1002,'LEDTV','Electronics','TV',45000);
insert into PRODUCTS values(1003,'Teddy','Toys','Soft Toy',800);
insert into PRODUCTS values(1004,'Pencil','Stationary','A pack of 12 pencils',80);
COMMIT;

