package com.cg.productmanagement.testcase;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;

import org.junit.Test;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exeption.ProductExecption;
import com.cg.productmanagement.service.DataValidator;

public class DataValidatorTest {
	DataValidator dataValidator;

	@Before
	public void setUp() throws Exception {
		dataValidator = new DataValidator();
	}

	@After
	public void tearDown() throws Exception {
		dataValidator = null;
	}

	@Test
	public void testIsValidProductCodeWithValidCode() {
		int productCode = 1001;
		assertTrue(dataValidator.isValidProductCode(productCode));
	}

	@Test
	public void testIsValidProductCodeWithInValidCode() {
		int productCode = -1001;
		assertFalse(dataValidator.isValidProductCode(productCode));
	}

	@Test
	public void testIsValidProductCodeWithZero() {
		int productCode = 0;
		assertFalse(dataValidator.isValidProductCode(productCode));
	}

	@Test
	public void testIsValidQuantityWithPositiveNumber() {
		int quantity = 2;
		assertTrue(dataValidator.isValidQuantity(quantity));

	}

	@Test
	public void testIsValidQuantityWithNegativeNumber() {
		int quantity = -2;
		assertFalse(dataValidator.isValidQuantity(quantity));
	}

	@Test
	public void testIsValidQuantityWithZero() {
		int quantity = 0;
		assertFalse(dataValidator.isValidQuantity(quantity));
	}

	@Test
	public void testIsProductExistedWithExistingProductCode() {
		int productCode = 1002;
		try {
			Product product = dataValidator.isProductExisted(productCode);
			assertNotNull(product);
		} catch (ProductExecption e) {
			fail(e.getMessage());
		}

	}

	@Test(expected = ProductExecption.class)
	public void testIsProductExistedWithNonExistingProductCode()
			throws ProductExecption {
		int productCode = 2017;
		Product product = dataValidator.isProductExisted(productCode);
		assertNull(product);
	}

	@Test
	public void testIsValidProductAndQuantityWithValidProductCodeAndQuantity()
			throws ProductExecption {
		int productCode = 1002;
		int quantity = 2;
		assertTrue(dataValidator.isValidProductAndQuantity(productCode,
				quantity));

	}

	@Test(expected = ProductExecption.class)
	public void testIsValidProductAndQuantityWithInValidProductCodeAndQuantity()
			throws ProductExecption {
		int productCode = -1002;
		int quantity = 0;
		assertFalse(dataValidator.isValidProductAndQuantity(productCode,
				quantity));

	}

	@Test
	public void testCalculateTotalWithValidPriceAndQuantity()
			throws ProductExecption {
		int productCode = 1002;
		int quantity = 2;
		double total = dataValidator.calculateTotal(productCode, quantity);
		assertEquals(90000, total, 20);
	}

	@Test(expected = ProductExecption.class)
	public void testCalculateTotalWithInValidPriceAndQuantity()
			throws ProductExecption {
		int productCode = 2005;
		int quantity = 2;
		double total = dataValidator.calculateTotal(productCode, quantity);
		fail("Exception Expected");
	}

}
