package com.cg.productmanagement.testcase;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;

import org.junit.Test;

import com.cg.productmanagement.dao.DBHelper;
import com.cg.productmanagement.exeption.ProductExecption;

public class DBHelperTest {
	DBHelper dbHelper;

	@Before
	public void setUp() throws Exception {
		dbHelper = new DBHelper();
	}

	@After
	public void tearDown() throws Exception {
		dbHelper = null;
	}

	@Test
	public void testGetProductDetailsWithValidProductCode() {
		int productCode = 1003;
		try {
			dbHelper.getProductDetails(productCode);
		} catch (ProductExecption e) {
			fail(e.getMessage());
		}

	}

	@Test(expected = ProductExecption.class)
	public void testGetProductDetailsWithInvalidCode() throws ProductExecption {
		int productCode = 0;
		dbHelper.getProductDetails(productCode);
		fail("Product Exception expected");
	}

	@Test(expected = ProductExecption.class)
	public void testGetProductDetailsWithNegativeValueAsCode()
			throws ProductExecption {
		int productCode = -1005;
		dbHelper.getProductDetails(productCode);
		fail("Product Exception expected");
	}

	@Test(expected = ProductExecption.class)
	public void testGetProductDetailsWithNonExistingProductCode()
			throws ProductExecption {
		int productCode = 2000;
		dbHelper.getProductDetails(productCode);
		fail("Product Exception expected");
	}

}
