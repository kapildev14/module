package com.cg.productmanagement.service;

import java.util.Set;
import java.util.TreeSet;

import com.cg.productmanagement.dao.DBHelper;
import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exeption.ProductExecption;

public class DataValidator {
	DBHelper dbHelper;
	static Product product;

	public DataValidator() {
		dbHelper = new DBHelper();
	}

	public boolean isValidProductCode(int productCode) {
		// product code should be positive else it returns false
		return productCode > 0 ? true : false;
	}

	public boolean isValidQuantity(int quantity) {
		// quantity should be positive else it returns false
		return quantity > 0 ? true : false;
	}

	public Product getProductByCode(long productCode) throws ProductExecption {
		return dbHelper.getProductDetails(productCode);

	}

	public Product isProductExisted(int productCode) throws ProductExecption {
		return dbHelper.getProductDetails(productCode);
	}

	public boolean isValidProductAndQuantity(int productCode, int quantity)
			throws ProductExecption {
		boolean flag = true;

		if (!isValidProductCode(productCode)) {
			flag = false;
			throw new ProductExecption("Product code should be positive");
		}
		product = isProductExisted(productCode);
		if (!isValidQuantity(quantity)) {
			flag = false;
			throw new ProductExecption("Quantity should be More Than Zero");
		}
		return flag;
	}

	public double calculateTotal(int productCode, int quantity)
			throws ProductExecption {
		double total = 0;
		if (isValidProductAndQuantity(productCode, quantity)) {
			double price = product.getProductPrice();
			total = price * quantity;
		}
		return total;
	}

}
