package com.cg.productmanagement.exeption;

public class ProductExecption extends Exception {
	public ProductExecption(String message) {
		super(message);
	}

}
