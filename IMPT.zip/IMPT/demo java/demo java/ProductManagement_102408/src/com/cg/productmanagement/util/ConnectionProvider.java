package com.cg.productmanagement.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;



public class ConnectionProvider {
	private static String dbUrl;
	private static String dbUid;
	private static String dbPwd;
	
	static{
		try {
			//Load Driver
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			//Read DB Properties
			Properties props = new Properties();
			props.load(new FileInputStream("res/db.properties"));
			
			//Read properties
		     dbUrl = props.getProperty("db.url");
			 dbUid = props.getProperty("db.uid");
		     dbPwd = props.getProperty("db.pwd");
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}
		public static Connection getConnection() throws SQLException{
			return DriverManager.getConnection(dbUrl, dbUid, dbPwd);
		
		
     }
	

	
}
