package com.cg.productmanagement.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exeption.ProductExecption;
import com.cg.productmanagement.service.DataValidator;

public class Client {
	static Scanner sc;
	static DataValidator dataValidator;
	private static double total;
	private static int productCode;
	private static int quantity;

	public static void main(String[] args) {
		// Configure the properties file of Log4j
		PropertyConfigurator.configure("res/log4j.properties");
		sc = new Scanner(System.in);

		dataValidator = new DataValidator();

		int choice = 0;
		while (choice != 3) {
			// Displays the Choice Menu
			System.out.println("Choice\tMenu");
			System.out.println("============");
			System.out.println("1  Enter Product Details");
			System.out.println("2  Calculating Total and displaying the bill");
			System.out.println("3  Exit");
			System.out.println("Choice ? ");
			// read choice value from console
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				try {
					// call the enterProductDetails() method in this class
					enterProductDetails();
				} catch (ProductExecption e) {
					System.out.println(e.getMessage());

				}
				break;
			case 2:
				try {
					// call the calucalateAndDisplay() method in this class
					calucalateAndDisplay();
				} catch (ProductExecption e) {
					System.out.println(e.getMessage());

				}
				break;
			default:
				System.out.println("Enter Correct Choice");
				break;
			}
		}
	}

	private static void calucalateAndDisplay() throws ProductExecption {
		Product product = dataValidator.getProductByCode(productCode);
		if (product == null)
			System.out.println("No Product is Found");
		else {
			// display the below values on console
			System.out.println("Product Name:       \t"
					+ product.getProductName());
			System.out.println("Product Category:   \t"
					+ product.getProductCategory());
			System.out.println("Product Description:\t "
					+ product.getProductDescription());
			System.out.println("Product Price (Rs): \t"
					+ product.getProductPrice());
			System.out.println("Quantity:           \t " + quantity);
			System.out.println("Line Total (Rs):    \t" + total);
		}
	}

	private static void enterProductDetails() throws ProductExecption {
		System.out.println("Enter the Product Code");
		productCode = sc.nextInt();
		System.out.println("Enter the quantity");
		quantity = sc.nextInt();
		// call the isValidProductAndQuantity() method in DataValidator class
		dataValidator.isValidProductAndQuantity(productCode, quantity);
		// return total value calculated in calculateTotal() method
		total = dataValidator.calculateTotal(productCode, quantity);
	}

}
