package com.cg.productmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;

import org.apache.log4j.Logger;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.exeption.ProductExecption;
import com.cg.productmanagement.util.ConnectionProvider;

public class DBHelper {
	private static final String GET_PRODUCT_QRY = "SELECT * FROM PRODUCTS WHERE PRODUCT_CODE=?";
	Logger logger = Logger.getLogger("dao");

	public Product getProductDetails(long productCode) throws ProductExecption {
		Product product = null;

		try {
			Connection con = ConnectionProvider.getConnection();
			logger.info("Connection is Created");
			PreparedStatement ps = con.prepareStatement(GET_PRODUCT_QRY);
			logger.info("Prepared Statement is Created");
			ps.setDouble(1, productCode);
			ResultSet rs = ps.executeQuery();
			logger.info("ResultSet Object is created");
			if (rs.next()) {
				product = new Product();
				product.setProductId(rs.getLong(1));
				product.setProductName(rs.getString(2));
				product.setProductCategory(rs.getString(3));
				product.setProductDescription(rs.getString(4));
				product.setProductPrice(rs.getDouble(5));
			} else
				throw new ProductExecption("Product code is not Existed");
		} catch (SQLException exp) {
			logger.error(exp);
			logger.error(Arrays.toString(exp.getStackTrace()));
			throw new ProductExecption("Retrieving details Failed");
		}
		return product;
	}

}
