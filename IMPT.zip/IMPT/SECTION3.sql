/DROP TABLE customer;

DROP TABLE customer succeeded./


CREATE TABLE customer(
  cust_id NUMBER(4) PRIMARY KEY,
  cust_name VARCHAR2(20),
  email VARCHAR2(40),
  mobile NUMBER(10),
  address VARCHAR2(50)
);

/CREATE TABLE succeeded./


INSERT INTO customer VALUES(2001,'Rohini','rohini@capgemini.com',8989898989,'Pune');

/1 rows inserted/


INSERT INTO customer VALUES(2002,'Satyen','satyen@capgemini.com',8765457899,'Mumbai');

/1 rows inserted/


INSERT INTO customer VALUES(2003,'Rashmi','rashmi@capgemini.com',9867563423,'Bangalore');

/1 rows inserted/


INSERT INTO customer VALUES(2004,'Bala','bala@capgemini.com',7856432311,'Chennai');

/1 rows inserted/


CREATE TABLE Feedback(
  Feed_BackID NUMBER(4) PRIMARY KEY,
  cust_id NUMBER(4) REFERENCES customer(cust_id),
  Vehicle_NO VARCHAR2(20),
  Vehicle_Type VARCHAR2(10),
  Service_date DATE,
  Rating NUMBER(2)
);


/CREATE TABLE succeeded./


INSERT INTO Feedback VALUES(3001,2001,'TN 03 A1234','Sedan','26-JUN-14',8);

/1 rows inserted/


INSERT INTO Feedback VALUES(3002,2001,'KA 05 K3456','HatchBack','13-MAY-14',7);

/1 rows inserted/


INSERT INTO Feedback VALUES(3003,2002,'MA 15 M6789','SmallCar','20-FEB-14',10);

/1 rows inserted/


INSERT INTO Feedback VALUES(3004,2001,'TN 07 H4567','Luxry','26-JUN-14',6);

/1 rows inserted/


INSERT INTO Feedback VALUES(3005,2003,'KA 12 Y5567','SUV','17-AUG-14',9);

/1 rows inserted/


INSERT INTO Feedback VALUES(3006,2001,'KL 09 O8989','Compact','10-JUL-14',4);

/1 rows inserted/


COMMIT;

/COMMIT succeeded./


CREATE SEQUENCE Feed_Back START WITH 3007;

/CREATE SEQUENCE succeeded./



1.(a)

SELECT Feedback.Feed_BackID, customer.cust_name FROM Feedback, customer
WHERE Feedback.cust_id=customer.cust_id AND Feedback.Rating=10
GROUP BY(customer.cust_id)
HAVING TO_CHAR(Feedback.Service_Date,'MONTH')='June';

FEED_BACKID            CUST_NAME            

3003                   Satyen


3 rows selected



1.(b)

SELECT COUNT(*) FROM Feedback WHERE Rating>8;

COUNT(*)               

2                      

1 rows selected



INSERT INTO Feedback(Feed_BackID, cust_id, Vehicle_NO, Vehicle_Type, Service_date, Rating)
VALUES(Feed_Back.NEXTVAL,&cust_id,&Vehicle_NO,&Vehicle_Type,SYSDATE,&Rating);

1 rows inserted




