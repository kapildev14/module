------3-------------		   
SELECT c.ConsumerName 
FROM Electricity_Consumer c INNER JOIN Electricity_Bill e 
	ON c.ConsumerNo = e.ConsumerNo
where EXTRACT(DAY FROM BillPaidDate) >15 ;
					   