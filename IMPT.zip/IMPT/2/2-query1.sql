
--------1-----------
SELECT ConsumerNo,ConsumerName 
FROM Electricity_Consumer
WHERE UnitsConsumed = (
						select max(UnitsConsumed) 
						from Electricity_Consumer
					   );


					   

	



		
		
/*		

--------2----------
SELECT DISTINCT * 
FROM Electricity_Bill 
WHERE ConsumerNo IN 
		(SELECT * 
			From Electricity_Bill 
			GROUP BY BillPaidDate
			HAVING count(*)>1)
GROUP BY BillPaidDate
HAVING count(*)>1;



---------5------------

ALTER TABLE Electricity_consumer
ADD CONSTRAINTS Postive_units_only CHECK(UnitsConsumed UnitsConsumed>=0);
;


*/

/*
	
select * from Electricity_Consumer;
select * from Electricity_Bill;

desc Electricity_Consumer;

*/