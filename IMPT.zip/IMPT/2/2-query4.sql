-------4------------
ALTER TABLE Electricity_consumer
ADD BillPaymentDate DATE
ADD	BillPaymentDueDate DATE
;