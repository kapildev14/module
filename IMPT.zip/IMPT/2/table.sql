DROP TABLE electricity_Consumer CASCADE CONSTRAINTS;
DROP TABLE Electricity_bill;
DROP SEQUENCE billid_seq;
 
 
CREATE TABLE electricity_Consumer(
			consumerNo NUMBER(8) PRIMARY  KEY,
			ConsumerName VARCHAR2(20) NOT NULL,
			emailid VARCHAR2(35),
			UnitsConsumed NUMBER
			);
 
CREATE TABLE electricity_Bill (
			BillNO NUMBER PRIMARY KEY,
			consumerNo NUMBER REFERENCES electricity_Consumer(consumerno),
			billAmount NUMBER(6,2),
			billPaidDate DATE
			);
 
INSERT INTO electricity_Consumer VALUES(12322110,'Seema Joshi','seema.joshi@gmail.com',250);
INSERT INTO electricity_Consumer VALUES(17531111,'Amey Joshi','amey.j@gmail.com',345);
INSERT INTO electricity_Consumer VALUES(17533411,'Pravin T','pravin.t@gmail.com',457);
INSERT INTO electricity_Consumer VALUES(12432121,'Manoj Kulkarni','manoj.k@gmail.com',780);
INSERT INTO electricity_Consumer VALUES(12342111,'Shrikant Shinde','shrikant.shinde@gmail.com',90);
INSERT INTO electricity_Consumer VALUES(15432152,'Mahesh B','bMahesh@gmail.com',720);
 
 
INSERT INTO electricity_Bill VALUES(101,15432152,440.45,'25-MAY-2014');
INSERT INTO electricity_Bill VALUES(102,17533411,652.23,'2-JUN-2015');
INSERT INTO electricity_Bill VALUES(103,15432152,672.11,'5-AUG-2015');
INSERT INTO electricity_Bill VALUES(104,12432121,450.521,'16-AUG-2014');
INSERT INTO electricity_Bill VALUES(105,12322110,790,'4-FEB-2015');
INSERT INTO electricity_Bill VALUES(106,12342111,450.521,'25-AUG-2015');
INSERT INTO electricity_Bill VALUES(107,12322110,790,'24-FEB-2015');
INSERT INTO electricity_Bill VALUES(108,17531111,650.00,'17-JAN-2016');
INSERT INTO electricity_Bill VALUES(109,17533411,1790,'14-OCT-2015');
INSERT INTO electricity_Bill VALUES(110,17533411,450.521,'15-DEC-2016');
 
 
CREATE SEQUENCE Billid_Seq START WITH 111;