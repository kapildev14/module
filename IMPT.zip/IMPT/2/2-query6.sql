
	
----------6---------------
SELECT e.BillNo,c.UnitsConsumed,e.BillAmount,c.ConsumerName 
FROM Electricity_Consumer c INNER JOIN Electricity_Bill e ON c.ConsumerNo = e.ConsumerNo;
	
		