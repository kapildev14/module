-----/* comments /-----------
/*
	This script can handle mulitple bills of same user 
	for different months based on his units consumption
	if the data exists.

*/


CREATE OR REPLACE PROCEDURE BillCharges(
c_id			IN 	Electricity_Consumer.ConsumerNO%TYPE,
errmsg		OUT	VARCHAR
)
 

IS
	slab_charge	 	 number;
	wrong_units 	 EXCEPTION;
	no_id 	         EXCEPTION;
	temp_cons  		 Electricity_Consumer%rowtype;
	temp_cons1  		 Electricity_Consumer%rowtype;
	bill 			 number;
	
	CURSOR consumer IS
		SELECT *
		FROM Electricity_Consumer
		WHERE ConsumerNo = c_id; 
		
BEGIN
	
	SELECT *
	INTO temp_cons1
	FROM Electricity_Consumer
		WHERE ConsumerNo = c_id;
	
	
	-------exception handlin---------------
	IF temp_cons1.UnitsConsumed <0  THEN
		RAISE wrong_units;
	END IF;
	
	
	----------------code block to compute ----------------
	OPEN consumer;
	LOOP
		FETCH consumer INTO temp_cons; 
		EXIT WHEN consumer%NOTFOUND;
			
		 
			if temp_cons.UnitsConsumed >100 then
				slab_charge := 5.56;
			else
				slab_charge := 2.96;
			end if;
			
			bill := slab_charge*temp_cons.UnitsConsumed;
						
			DBMS_OUTPUT.PUT_LINE(bill||'  ');
	END LOOP;
	CLOSE consumer;
	

EXCEPTION
	WHEN NO_DATA_FOUND THEN
		errmsg := 'Consumer Does not exist';
	WHEN wrong_units THEN
		errmsg := 'UnitsConsumed cannot be negative';		
	WHEN OTHERS THEN
		errmsg := SQLERRM;
 
END;
/		

show error
set serveroutput on;
variable err varchar2(100)	;







-- below prcocedure call is valid-----
--exec BillCharges(17533411,:err)



---- below procedure call id invalid
/*
exec BillCharges(1342111,:err)
print err;
*/

/*
-----------debugging --------------------

select * from Electricity_Consumer;
select * from Electricity_Bill;

show error
variable bill number;

exec BillCharges(1342111,:err)
print err;
*/
 