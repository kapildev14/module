function istitleSelected(){
selected=false;

r1=document.getElementById("rbMr");
r2=document.getElementById("rbMrs");
r3=document.getElementById("rbMs");

if(r1.checked || r2.checked ||r3.checked){
checked=true;
}
return selected;
}

function isValidShowDate(){
isValid=false;
sdElement=document.getElementById("txtSD");
sd= new Date();
today= new Date();

if(sd>today){
isValid=true;
}
return isValid();
}

function Validate(){
var isValid=true;

if(!istitleSelected()){
isValid=false;
alert("please select the title");
}

if(!isValidShowDate()){
isValid=false;
alert("The show date should be today or later");
}

if(isValid){
display();
}
return isValid;
}

function getTotalFare(){
classElement=document.getElementById("selclass");
adultsElement=document.getIdByElement("txtadult");
childsElement=document.getIdByElement("txtchild");

clazz=classElement.value;
adCount=parseInt(adultsElement.value);
cdCount=parseInt(childsElement.value);
 var fare;
 
 if(clazz=="DC") fare=560;
 else if(clazz=="GD") fare=350;
 else if(clazz=="SD") fare=250;
 
 totalFare=fare*adCount+((fare/2)*cdCount);
 return totalFare;
 }
 
 function display(){
 r1=document.getElementById("rbMr");
 r2=document.getElementById("rbMrs");
 r3=document.getElementById("rbMs");
 
 var title;
 
 if(r1.checked) title="Mr"
 else if(r2.checked) title="Mrs"
 else if(r3.checked) title="Ms";
 
 name=document.getElementById("txtname").value;
 showDate=document.getElementById("txtSD").value;
 clazz=document.getElementById("selclass").value;
 totalFare=getTotalFare();
 
 alert(title +""+name+"Please pay Rs "+totalFare+"to book show on"+showDate);
 
 outputWin=open();
 
 outputwin.document.writein("<h2>"+title+""+name+"Please pay Rs."+totalFare+"to book showon "+showDate+"</h2>");

}


