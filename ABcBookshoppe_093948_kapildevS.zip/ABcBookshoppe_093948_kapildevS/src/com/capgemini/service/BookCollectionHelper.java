package com.capgemini.service;


	import java.util.ArrayList;
	import java.util.HashSet;
	import java.util.Iterator;

	import com.capgemini.bean.Book;

	public class BookCollectionHelper {
		//private  static ArrayList<Book> bookList=null;
		private  static HashSet<Book> bookList=null;
		static
		{
			
			
			bookList=new HashSet<Book>();
			
		//	HashSet<Book> set=new HashSet<Book>();  
		    //Creating Books  
		
			Book b1=new Book(101,"Sea of C",350);
			Book b2=new Book(102,"Java For Beginners",200);
			Book b3=new Book(103,"Learn Java in 21 Days", 300);
			Book b4=new Book(104,"Learn .Net With C# in 21 Days", 350);
			Book b5=new Book(105,"C++ Programming for Beginners", 200);

			bookList.add(b1);
			bookList.add(b2);
			bookList.add(b3);	
			bookList.add(b4);
			bookList.add(b5);
			
			
		}
	public BookCollectionHelper(){}
		
		//Add New Book in Hashset
	
		public void addNewBookDetails(Book book) 
		{			
				bookList.add(book);				
		}
		
		public static HashSet<Book> getbookList() {
			return bookList;
		}

		public static void setbookList(HashSet<Book> bookList) {
			BookCollectionHelper.bookList = bookList;
		}

		
		//Fetch All Book Details 

		public static  void displayBookCount()
		{
			Iterator<Book> bookIt=bookList.iterator();
			Book tempBook=null;
			
			int totalCount=0;
			while(bookIt.hasNext())
			{
				totalCount++;
				tempBook=bookIt.next();
				System.out.println(tempBook);			
			}
			System.out.println("Total Count of Books" + totalCount);
		}
	}


