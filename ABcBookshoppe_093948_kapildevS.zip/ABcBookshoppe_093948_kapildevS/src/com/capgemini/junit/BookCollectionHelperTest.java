package com.capgemini.junit;


import junit.framework.Assert;

import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.capgemini.bean.Book;
import com.capgemini.exception.BookException;
import com.capgemini.service.BookCollectionHelper;

public class BookCollectionHelperTest {
	static BookCollectionHelper collectionHelper;
	static Book book=null;

	@BeforeClass
	public   static  void beforeClass()
	{
		collectionHelper=new BookCollectionHelper();
		book =new Book(121,"kapil", 600);		
	}
	@AfterClass
	public static  void afterClass()
	{		
		collectionHelper=null;
		book=null;
	}	


	@Test 
	public void testAddNewBook() throws BookException
	{
		collectionHelper.addNewBookDetails(book);
		//Assert.assertEquals(4, collectionHelper.getCustList().size());
		Assert.assertNotNull(collectionHelper.toString());

	}
}
