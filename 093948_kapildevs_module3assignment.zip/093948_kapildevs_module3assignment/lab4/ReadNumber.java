package Com.capgemini.lab4;


	import java.io.BufferedReader;
	import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.regex.Pattern;

	public class ReadNumber {
		
		
			private static final Pattern COMMA = Pattern.compile(",");

			public static void main(String[] args) {
				 try {
			            BufferedReader myReader =
			            new BufferedReader(new FileReader("C:\\Users\\KADEVS\\Desktop\\number.txt"));

			            ArrayList<Integer> myList = new ArrayList<Integer>();
			            int t[]=new int[11];
			            int p=0;
			            String line;
			            while ((line = myReader.readLine()) != null) {
			                for (String token : COMMA.split(line)) {
			                    try {
			                        t[p]= Integer.parseInt(token);
			                        p++;
			                    } catch (NumberFormatException ex) {
			                        System.err.println(token + " is not a number");
			                    }
			                }
			                
			            }
			            for(p=0;p<t.length;p++)
			            {
			            	int pp=t[p];
			            		
			            	if(pp%2==0 && pp>=0)
			            		{
			            			System.out.println(t[p]);
			            		}
			            }
			            myReader.close();
			        } catch(FileNotFoundException e){

			        } catch(IOException e){

			        }


			}

		}


