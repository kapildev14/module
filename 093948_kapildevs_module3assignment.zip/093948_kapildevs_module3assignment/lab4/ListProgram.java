package Com.capgemini.lab4;


	
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.Iterator;
	public class ListProgram {
	public static void main(String args[]){  
			  ArrayList<String> list=new ArrayList<String>(); //Creating arraylist  
			  list.add("TV"); //Adding object in arraylist  
			  list.add("AC");  
			  list.add("Washing Machine");  
			  list.add("Ref");  
			  //Traversing list through Iterator  
			  Iterator itr=list.iterator();  
			  while(itr.hasNext()){  
			   System.out.println(itr.next());  
			  }  
			  System.out.println();
			  System.out.println("Sorting of the array");
			  Collections.sort(list);

			   for(String str: list){
					System.out.println(str);
			   }
			    
			 }  
	}



