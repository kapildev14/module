import java.util.HashMap;
import java.util.Map;


public class MapEmp {
 public Map<String,String>getEmployeeDetails(){
	 Map<String,String>EmployeeMap=new HashMap<String,String>();
	 EmployeeMap.put("100","arun");
	 EmployeeMap.put("200","akhila");
	 EmployeeMap.put("300","ankitha");
	 EmployeeMap.put("400","utsahini");
	 EmployeeMap.put("500","Arul");
	 return EmployeeMap;
	 
	 
 }
}
