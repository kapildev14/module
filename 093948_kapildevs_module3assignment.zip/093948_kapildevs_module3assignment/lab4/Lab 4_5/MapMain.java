import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class MapMain {
public static void main(String[] args) {
	MapEmp e=new MapEmp();
	Map<String,String>EmployeeMap=e.getEmployeeDetails();
	System.out.println(EmployeeMap);
	Set<String>Keys=EmployeeMap.keySet();
	Iterator<String>Iterator=Keys.iterator();
	System.out.println("EmployeeDetails");
	while(Iterator.hasNext()){
		String id=Iterator.next();
		String name=EmployeeMap.get(id);
		System.out.println("id:"+id + " name:"+name);
	}
	
}
}
