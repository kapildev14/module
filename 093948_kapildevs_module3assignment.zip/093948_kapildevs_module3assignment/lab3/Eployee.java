package Com.capgemini.lab3;

import Com.capgemini.lab2.Userdefined3_2;

public class Eployee {
	
	String name;
	float age;
	 Eployee(){
		System.out.println("Person age default constructor");
	}
	 Eployee(String name,float age){
		super();
		this.name=name;
		this.age=age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws Userdefined3_2 {
		if(age<=15) {
			throw new Userdefined3_2("Age should be greater than 15");
		}
		else
		{
		this.age = age;
		}
	}
	public void print() {
		System.out.println(this);
	}
	public String toString() {
		return getName()+" "+getAge();
	}


	}



