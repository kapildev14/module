package Com.capgemini.lab3;

import java.util.Scanner;

public class EployeeMain {
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			try {
                Eployee p=new Eployee();
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter the name");
				String name=sc.nextLine();
				p.setName(name);
				System.out.println("Enter the age");
				float age=sc.nextFloat();
				p.setAge(age);
				p.print();
			}
			catch(Exception m) {
				System.out.println("Exception Occured "+m);
			}
		}


}
