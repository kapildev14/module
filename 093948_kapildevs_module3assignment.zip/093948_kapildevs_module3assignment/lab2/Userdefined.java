package Com.capgemini.lab2;

public class Userdefined extends Exception{
	public Userdefined() {
		super();
	}
	public Userdefined(String s){
		super(s);
	}
}

