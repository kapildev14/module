package Com.capgemini.lab2;

import java.util.Random;

public class Account {
	long accNum;
	double balance;
	Person accHolder;
	{
		accNum = 10000000l + new Random().nextInt();
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit(double amt) {
		balance=balance+amt;
	}
	public void withdraw(double amt) {
		balance=balance-amt;
	}
	public Account() {
		
	}
	public Account(double balance, Person accHolder) {
		super();
		this.balance = balance;
		this.accHolder = accHolder;
	}
	public void print() {
		System.out.println(this);
	}
	public String toString() {
		return accHolder.toString()+"\nAccount Number:" + accNum+ "\nBalance:" + getBalance();
	}
}
