package Com.capgemini.lab2;


public class Userdefined3_2 extends Exception{
	public Userdefined3_2() {
		super();
	}
	public Userdefined3_2(String s){
		super(s);
	}
}
