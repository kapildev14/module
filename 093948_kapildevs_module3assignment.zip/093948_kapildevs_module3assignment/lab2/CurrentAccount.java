package Com.capgemini.lab2;

public class CurrentAccount extends Account{

	public double overdraftLimit=1000;
	public boolean withdrawn(double amt) {
		if(amt>=overdraftLimit) {
			return false;
		}
		else 
		{
			return true;
		}
	}
	
	public CurrentAccount(){
		
	}
	
	public CurrentAccount(double balance,Person accHolder) {
		super();
		this.balance=balance;
		this.accHolder=accHolder;
	}
	
	public void print() {
		System.out.println(this);
	}
	public String toString() {
		return accHolder.toString()+"\nAccount Number:" + accNum+ "\nBalance:" + getBalance();
	}
}


