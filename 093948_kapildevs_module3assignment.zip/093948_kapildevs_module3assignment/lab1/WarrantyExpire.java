package Com.capgemini.lab1;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class WarrantyExpire {

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the Date you purchased the product in dd/mm/yyyy format");
		String purchasedDate=in.nextLine();
		String date1[]=purchasedDate.split("/");
		int year=Integer.parseInt(date1[2]);
		int month=Integer.parseInt(date1[1]);
		int day=Integer.parseInt(date1[0]);
		System.out.println("Enter the Warranty period in month and years format");
		int month1=in.nextInt();
		int year1=in.nextInt();
		
		LocalDate startDate = LocalDate.of(year, month, day);
		String warranty=startDate.plusMonths(month1).plusYears(year1).toString();
		System.out.println(warranty);
	}

}
