package Com.capgemini.lab1;


import java.text.ParseException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Datediff{

	public static void main(String[] args) throws ParseException {
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter date in dd/MM/yyyy format: ");
		String input = sc.nextLine();

		LocalDate enteredDate = LocalDate.parse(input, formatter);
		//Period period = enteredDate.until(today);

		
		System.out.println("Enter date in dd/MM/yyyy format: ");
		String input1 = sc.nextLine();

		LocalDate enteredDate1 = LocalDate.parse(input1, formatter);
		Period p = enteredDate1.until(enteredDate);
		
		System.out.println("Days: " + p.getDays());
		System.out.println("Months:" + p.getMonths());
		System.out.println("Years:" + p.getYears());
	}

}