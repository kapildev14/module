package Com.capgemini.lab1;

import java.time.LocalDate;
import java.time.Period;

public class Person {
	
	private String firstname, lastname, gender, phonenumber;
	
	public Person() {
		System.out.println("***********************");
		System.out.println("In Default Constructor.");
	}
	
	public Person(String fname, String lname, String gen, String phonenum) {
		System.out.println("In Parameterized Constructor.");
		this.firstname=fname;
		this.lastname=lname;
		this.gender=gen;
		this.phonenumber=phonenum;
	}
	
	public void setName(String f, String l) {
		this.firstname=f;
		this.lastname=l;
	}
	
	public String getFullName() {
		return firstname+" "+lastname;
	}
	
	public void setGender(String g) {
		this.gender=g;
	}
	
	public String getGender() {
		return gender;
	}
	
	public void setPhoneNum(String pn) {
		this.phonenumber=pn;
	}
	
	public String getPhoneNum() {
		return phonenumber;
	}
	
	public void display() {
		System.out.println();
		System.out.println("First Name: "+firstname+
							"\nLast Name: "+lastname+
							"\nGender: "+gender+
							"\nPhone Number: "+phonenumber);
		System.out.println();
	}

public void calculateAge(String dob) {
	String date[] = dob.split("/");
	int day = Integer.parseInt(date[0]);
	int month = Integer.parseInt(date[1]);
	int year = Integer.parseInt(date[2]);
	
	LocalDate endofCentury = LocalDate.of(year, month, day);
	LocalDate now = LocalDate.now();
	
	Period diff = Period.between(endofCentury, now);
	
	System.out.println("Your Age is "+diff.getYears()+" years, "+diff.getMonths()+" months and "+diff.getDays()+" days old.");
	
}
}
	