package Com.capgemini.lab1;

import java.util.Scanner;

public class CommandLine {
	public static void main(String[] args) {
		
		int num;
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Integer: ");
		num = in.nextInt();
		
		if(num>0)
			System.out.println(num+" is a positive num.");
		else
			System.out.println(num+" is a negative num.");
	}
}
