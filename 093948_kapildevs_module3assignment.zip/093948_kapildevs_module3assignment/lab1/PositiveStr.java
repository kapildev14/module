package Com.capgemini.lab1;
	
import java.util.*;

class checkStr {
	public boolean checkStr(String str) {
		for(int i=0; i<str.length(); i++) {
			if((i<str.length()-1) && (str.charAt(i)>str.charAt(i+1)))
				return false;
		}
		return true;
	}
}

public class PositiveStr {
	public static void main(String[] args) {
		String str;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter a string: ");
		str = in.nextLine();
		checkStr obj = new checkStr();
		
		if(obj.checkStr(str))
			System.out.println("Positive Str.");
		else
			System.out.println("Negative Str.");
	}
}



