package Com.capgemini.lab1;

import java.util.Scanner;

public class StringOperations {
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String");
		String input=sc.nextLine();
		System.out.println("Enter the option");
		System.out.println("1.Add the String to itself");
		System.out.println("2.Replace odd positions with #");
		System.out.println("3.Remove duplicate characters in the String");
		System.out.println("4.Change odd characters to upper case");
		int opt=sc.nextInt();
		if(opt==1) 
		{
			StringBuilder str = new StringBuilder(input+" ");
			str.append(input);
			System.out.println("The Added String to itself "+str);
		}
		else if(opt==2)
		{
			for (int i=0; i <= input.length(); i++)
			{
		        if (i % 2 != 0)
		        {
		          input = input.substring(0,i-1) + "#" + input.substring(i, input.length());
		        }
		      }
			System.out.println(input);
		}
		else if(opt==3) 
		{
			char[] characters = input.toCharArray();
			int length=characters.length;
			for(int i=0; i<length;i++)
			{
				for(int j=i+1;j<length;j++)
				{
					if(characters[i] == characters[j])
					{
						int temp=j;
						for(int k=temp;k<length - 1;k++)
						{
							characters[k]=characters[k +1];
						}
			
			
	
	                    j--;
	                    length--;
	                }
	            }
	        }
			String input1 = new String(characters);
			input1 = input1.substring(0, length);
			System.out.println("String after duplicates removed : " + input1);
	    }
		else if(opt==4)
		{
			String c="";
			String newword="";
			for (int i=0; i < input.length(); i++)
			{
		        if (i % 2 != 0)
		        {
		        	c="";
		        	 c+=input.charAt(i);
		             c = c.toUpperCase();
		             newword+=c;
		        }
		        else
		        {
		        	c="";
		        	c+=input.charAt(i);
		            
		             newword+=c;
		        }
		    }
			System.out.println(newword);
		}
		else
		{
			System.out.println("Wrong Entry");
		}
	}


}
