package Com.capgemini.lab1;

import java.util.Scanner;

/*
class EmptyStringException extends Exception{
	public String toString() {
		return "Empty String";
	}
}
*/

public class PersonMain {
	
	public enum Gender{M, F};
	
	static boolean validateGender(String gender) {
		if(gender.equals(Gender.M) || (gender.equals(Gender.F)))
			return true;
		else
			return false;
	}
	
	public static void main(String[] args) {
		String fn, ln, g, phn, dob;
		String fullname;
		Scanner in = new Scanner(System.in);
		
		System.out.println("Enter First Name: ");
		fn = in.nextLine();
		
		System.out.println("Enter Last Name: ");
		ln = in.nextLine();
		
		fullname = fn+" "+ln;
		
		
		do {
			System.out.println("Enter Gender: ");
			g = in.nextLine();
		} while(validateGender(g));
		
		System.out.println("Enter Phone Number: ");
		phn = in.nextLine();
		
		System.out.println("Enter DOB in 'dd/mm/yyyy' format: ");
		dob = in.nextLine();
		
		Person p1 = new Person();
		p1.setName(fn, ln);
		p1.setGender(g);
		p1.setPhoneNum(phn);
		System.out.println("Name: "+p1.getFullName()+
							"\nGender: "+p1.getGender()+
							"\nPhone Number: "+p1.getPhoneNum());
		
		p1.display();
		p1.calculateAge(dob);
		System.out.println();
		
		Person p2 = new Person(fn, ln, g, phn);
		System.out.println("Name: "+p2.getFullName()+
							"\nGender: "+p2.getGender()+
							"\nPhone Number: "+phn);
		
	}
}
