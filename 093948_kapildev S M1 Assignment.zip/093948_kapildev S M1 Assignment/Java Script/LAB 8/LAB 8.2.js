function category()
{
	var catdata=window.document.form1.Cattype.value;
	//document.write(catdata);
	
	if(catdata=="Electronics")
	{
		window.document.form1.catval.options[0].text="Television";
		window.document.form1.catval.options[0].value="Television";
		
		window.document.form1.catval.options[1].text="Laptop";
		window.document.form1.catval.options[1].value="Laptop";
		
		window.document.form1.catval.options[2].text="Phone";
		window.document.form1.catval.options[2].value="Phone";
		
		
	}
	
	if(catdata=="Grocery")
	{
		window.document.form1.catval.options[0].text="soap";
		window.document.form1.catval.options[0].value="soap";
		
		window.document.form1.catval.options[1].text="powder";
		window.document.form1.catval.options[1].value="powder";
		
	}
	
}

function calculate()
{
	var quantity=window.document.form1.qua.value;
	var category=window.document.form1.catval.value;
	var tel=20000;
	var lap=30000;
	var phn=10000;
	var soa=40;
	var pow=90;
	var totprice;
	if(category=="Television")
	{
	     totprice=quantity*tel;	
	}
	if(category=="Laptop")
	{
	     totprice=quantity*lap;	
	}
	if(category=="Phone")
	{
	     totprice=quantity*phn;	
	}
	if(category=="soap")
	{
	     totprice=quantity*soa;	
	}
	if(category=="powder")
	{
	     totprice=quantity*pow;	
	}
	
	window.document.form1.tot.value=totprice;
	
}