package pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sele_class1 {
	
	//public static String  driverpath="C:\\Users\\KADEVS\\Downloads\\";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
		
		//1.Launch Browser
		
		WebDriver driver = new FirefoxDriver();
		
		//System.setProperty("webdriver.chrome.driver",driverpath+"chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
       //2. Navigate to URL
		
		driver.get("file:///C:/Users/KADEVS/Downloads/Demos/Demos/Lesson%205-HTML%20Pages/Lesson%205-HTML%20Pages/WorkingWithForms.html");
		
		//3.Username
		
		 driver.findElement(By.id("txtUserName")).sendKeys("kapildev");
		 driver.findElement(By.id("txtPassword")).sendKeys("Kap12345");
		 driver.findElement(By.id("txtConfPassword")).sendKeys("Kap12345");
		 driver.findElement(By.id("txtFirstName")).sendKeys("Kapil");
		 driver.findElement(By.id("txtLastName")).sendKeys("dev");
		 driver.findElement(By.id("rbMale")).click();
		 driver.findElement(By.id("DOB")).sendKeys("14/07/1996");
		 driver.findElement(By.id("txtEmail")).sendKeys("kapildev.14@gmail.com");
		 driver.findElement(By.id("txtAddress")).sendKeys("No.J140 Srirampuram");
		 driver.findElement(By.id("txtPhone")).sendKeys("8892155840");
		 //driver.findElement(By.xpath("//input[@value='Reading']")).click();
         driver.findElement(By.cssSelector("input[value='Music']")).click();
	
		
	
		 //driver.findElement(By.name("submit").SendKey.submit();
		 driver.close();
	}

}
