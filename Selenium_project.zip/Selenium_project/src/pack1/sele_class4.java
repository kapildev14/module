package pack1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class sele_class4 {

	public static void main(String[] args){
		
		WebDriver driver = new FirefoxDriver();
		
	
		driver.navigate().to("http://demo.opencart.com/");
		//driver.get("C:\\Users\\KADEVS\\Downloads\\Demos\\Demos\\Lesson 2 - Demos\\Lesson 2 - Demos\\HTML Pages\\LocatingElements.html");
		//driver.findElement(By.id("FN")).sendKeys("kapil");
		//driver.findElement(By.id("FN")).sendKeys(Keys.ENTER);
		//driver.findElement(By.id("FN")).clear();
		
		
		/*String expectedtitle="Email Detail";
		String actualtitle=driver.getTitle();
		System.out.println(actualtitle);
		System.out.println(expectedtitle.equals(actualtitle));*/
		
		/*boolean title=driver.getTitle().contains("Employee detail");
		System.out.println(title);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getPageSource());
		boolean txt=driver.getPageSource().contains("alert");
		System.out.println(txt);*/
		
		//gettext() method
		
		/*WebElement wb1 = driver.findElement(By.xpath("html/body/pre"));
		String htxt = wb1.getText();
		System.out.println(htxt);
		
		//get attribute method
		
		String str1=driver.findElement(By.id("FN")).getAttribute("type");
		System.out.println(str1);
		
		String str2=driver.findElement(By.id("FN")).getAttribute("value");
		System.out.println(str2);
		
		//Maximize browser window
		
		driver.manage().window().maximize();*/
		
		List<WebElement>linkElements=driver.findElements(By.tagName("a"));
		System.out.println(linkElements.size());
		String[] linkTexts=new String[linkElements.size()];
		int i=0;
		for (WebElement e: linkElements)
		{
			linkTexts[i]= e.getText();
			System.out.println("The hyperlink-text is"+e.getText());
		}
		
		
		driver.close();
	}
}

