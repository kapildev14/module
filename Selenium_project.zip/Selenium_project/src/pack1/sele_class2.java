package pack1;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class sele_class2{
	public static void main(String[] args){
		
				// 1.Launch the browser
		WebDriver driver = new FirefoxDriver();
		
				//2.Navigate to URL
		//driver.get("C:\\Users\\KADEVS\\Downloads\\Demos\\Demos\\Lesson 2 - Demos\\Lesson 2 - Demos\\HTML Pages\\LocatingElements.html");
		driver.navigate().to("C:\\Users\\KADEVS\\Downloads\\Demos\\Demos\\Lesson 2 - Demos\\Lesson 2 - Demos\\HTML Pages\\LocatingElements.html");
		driver.navigate().back();
		driver.findElement(By.cssSelector("input#FN")).sendKeys("kapil");
		driver.findElement(By.name("mname")).sendKeys("S");
		
		
		driver.findElement(By.id("LN")).sendKeys("Dev");
		driver.findElement(By.className("Format")).sendKeys("14/07/1996");
		
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[5]/td[2]/input")).sendKeys("8892155840");
		driver.findElement(By.id("EmailID")).sendKeys("kapildev14@gmail.com");
		driver.findElement(By.id("PNO")).sendKeys("BQj78321");
		
				//Find drop down
		  
		WebElement wb1 = driver.findElement(By.id("country"));
		
				// create an object
		Select sel = new Select(wb1);
		sel.selectByVisibleText("USA");
				sel.selectByValue("USA");
			sel.selectByIndex(3);
			
			WebElement wb3 = driver.findElement(By.id("city_input"));
					
					Select se = new Select(wb3);
			        se.selectByValue("Boston");
			driver.findElement(By.xpath("//input[@value='male']")).click();
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[11]/td[2]/input")).sendKeys("3");
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[12]/td[2]/input")).sendKeys("1");
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[13]/td[2]/input")).sendKeys("Kapildev");
			
			
		
		
		WebElement wb2 =driver.findElement(By.name("relation"));
		Select sele = new Select(wb2);
		sele.selectByIndex(2);
		//driver.findElement(By.linkText("Desktops")).click();
		driver.findElement(By.xpath("html/body/form/table/tbody/tr[15]/td[2]/textarea")).sendKeys("Kapildev");
		//driver.findElement(By.name("reset")).click();
	//	driver.findElement(By.name("submit")).click();
		driver.findElement(By.name("prev")).click();
		
	}
}
